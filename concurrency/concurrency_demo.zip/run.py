#!/usr/bin/env python3

"""
Python Concurrency Demo - Runner
This is a simple wrapper script that runs the concurrency_demo.py file.
"""

if __name__ == "__main__":
    import concurrency_demo
    concurrency_demo.main()
